# Leandro Lopez  
## Merrimack College  
## Advanced Concepts  
  
---
This is a flask application. To get the app running, use the command:  
flask --app app run
